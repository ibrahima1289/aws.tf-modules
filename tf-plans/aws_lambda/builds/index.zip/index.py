

def print_family_tree(event=None, context=None):
	def add_person(tree, name, parents=None):
		tree[name] = {'parents': parents if parents else []}

	def get_ancestors(tree, name, ancestors=None):
		if ancestors is None:
			ancestors = set()
		for parent in tree.get(name, {}).get('parents', []):
			ancestors.add(parent)
			get_ancestors(tree, parent, ancestors)
		return ancestors

	family_tree = {}
	# Add people
	add_person(family_tree, "John")
	add_person(family_tree, "Mary")
	add_person(family_tree, "Michael", ["John", "Mary"])
	add_person(family_tree, "Linda")
	add_person(family_tree, "Sophia", ["Michael", "Linda"])

	# Collect family members info
	members = []
	for name, info in family_tree.items():
		members.append(f"{name} (Parents: {', '.join(info['parents']) if info['parents'] else 'None'})")

	# Collect ancestors of Sophia
	ancestors = get_ancestors(family_tree, 'Sophia')
	result = '\n'.join(members) + f"\nAncestors of Sophia: {ancestors}"
	return result


if __name__ == "__main__":
	print(print_family_tree())
